package org.ip.session04;

import java.util.Locale;

public class SumaSerie {
	public static double sumaSerie(int i) {
         if (i == 1) {
              return 1.0 / 2.0;
         } else {
              return i / (i + 1.0) + sumaSerie(i - 1);
         }
 }
 public static void main(String[] args) {
	 System.out.println(" i\t" + " SUMA");
	 for (int i = 1; i <= 10; i++) {
		 System.out.printf(Locale.ENGLISH, "%2d\t%7.6f\n", i,sumaSerie(i)); 
		}
}
}
