package org.ip.session04;

import java.util.Scanner;

public class DivisoresPrimos {
	public static boolean esPrimo(int numero) {
		int divisor = 2;
		boolean primo = true;
		if (numero % divisor == 0)
			primo = false;
		for (divisor = 2; divisor <= Math.sqrt(numero); divisor++) {
			if (numero % divisor == 0) {
				primo = false;
		    }
		}
		if (numero == 2)
			primo = true;
		return primo;
	}
	public static void divisoresPrimos(int numero) {
		System.out.print("Los divisores primos de " + numero + " son:");
		for (int i = 2; i <= numero; i++) {
			if (esPrimo(i) && numero % i == 0) {
				System.out.print(i + " ");
		    }
		}
	}
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner entrada = new Scanner(System.in);
		System.out.print("Introduzca un numero: ");
		int numero = entrada.nextInt();
		divisoresPrimos(numero);
    }
}


