package org.ip.session04;

import java.util.Scanner;

public class Cilindro {
	public static void areaVolumenCilindro(double radio, double altura,
			int opcion) {
		double area, volumen;
		switch (opcion) {
		case 1:
		area = (2 * Math.PI * radio * (altura + radio));
		System.out.println("El area del cilindro es de: " +
		area);
		break;
		case 2:
		volumen = (Math.PI * (radio * radio) * altura);
		System.out.println("El volumen del cilindro es de: " +
		volumen);
		break;
		}
		}
		public static void main(String[] args) {
			double radio, altura;
			@SuppressWarnings("resource")
			Scanner entrada = new Scanner(System.in);
			System.out.print("Introduzca radio: ");
			radio = entrada.nextDouble();
			System.out.print("Introduzca altura: ");
			altura = entrada.nextDouble();
			System.out.print("Que desea calcular (1 (area) / 2 (volumen): ");
			int opcion = entrada.nextInt();
			System.out.println();
			areaVolumenCilindro(radio, altura, opcion);
		}
}


