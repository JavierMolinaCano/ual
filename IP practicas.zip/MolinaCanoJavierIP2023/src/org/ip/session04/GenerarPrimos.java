package org.ip.session04;

public class GenerarPrimos {
	public static boolean esPrimo(int numero) {
		 int divisor = 2;
		 boolean primo = true;
		 if (numero % divisor == 0)
			 primo = false;
		 for (divisor = 2; divisor <= Math.sqrt(numero); divisor++) {
			 if (numero % divisor == 0) {
				 primo = false;
		     }
		 }
		 if (numero == 2)
			 primo = true;
		 return primo;
		 }
	public static void main(String[] args) {
		 int numero = 2;
		 int linea = 0;
		 System.out.println("Los 50 primeros numeros primos son:\n");
		 while (linea != 50) {
			 if (esPrimo(numero)) {
		 }
		 System.out.printf("\t%3d", numero);
		 linea++;
		 if (linea % 10 == 0) {
		 System.out.println();
		 }
		 }
		 numero++; 
			
		}
}


