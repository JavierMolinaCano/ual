package org.ip.session04;

import java.util.Scanner;

public class Sumatoria {
	public static int sumaIterativa(int x) {
		 int n = 0;
		 for (int i = 1; i <= x; i++) {
		      n = (i * (i + 1) / 2);
		 }
		 x = n;
		 return x;
	}
	public static int sumaDirecta(int x) {
		 x = x * (x + 1) / 2;
		 return x;
    }
    public static int sumaRecursiva(int x) {
		 if (x == 0) {
	    	 return 0;
		 } else if (x == 1) {
		       return 1;
		 } else {
		       return x + sumaRecursiva(x - 1);
		 }
    }
		 public static void main(String[] args) {
		 @SuppressWarnings("resource")
		 Scanner entrada = new Scanner(System.in);
		 System.out.println("Introduzca el numero de terminos que desea sumar");
		 int x = entrada.nextInt();

		 System.out.println();

		 System.out.println("La suma usando el metodo iterativo de los " + x + " primeros numeros es " + sumaIterativa(x));
		 System.out.println("La suma usando el metodo directo de los " + x + " primeros numeros es " + sumaDirecta(x));
		 System.out.println("La suma usando el metodo recursivo de los " + x + " primeros numeros es " + sumaRecursiva(x));

		 System.out.println();

		 if (sumaIterativa(x) == sumaDirecta(x) && sumaIterativa(x) ==
		sumaRecursiva(x))
		 System.out.println("Funcionamiento correcto"); 

		}
}


