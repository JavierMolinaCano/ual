package org.ip.session04;

import java.util.Scanner;

public class ValidarFecha {
	public static  boolean esFechaCorrecta(int dia, int mes, int anio) {
		 boolean fecha;
		 if (anio <= 0) {
		      fecha = false;
		 } else {
		      if (mes == 2 && (1 <= dia && dia <= 28)) {
		            fecha = true;
		      } else {
		           if (mes == 4 || mes == 6 || mes == 9 || mes == 11
&& 1 <= dia && dia <= 30) {
	                	 fecha = true;
		                   } else {
		                        if (mes == 1 || mes == 3 || mes == 5 || mes
== 7 || mes == 8 || mes == 10
		                                   || mes == 12 && 1 <= dia && dia
<= 31) {
		                             fecha = true;
		                    } else {
		                             fecha = false;
		                    }
		               }
		         }
		   }
		   return fecha;
		 }
		 public static boolean esBisiesto(int anio) {
		      boolean fecha;
		      if (anio % 4 == 0 && anio % 100 != 0 || anio % 400 == 0) {
		            fecha = true;
		      } else
		           fecha = false;
		      return fecha;
		 }
		 public static void main(String[] args) {
		       int dia, mes, anio;
		       @SuppressWarnings("resource")
		       Scanner entrada = new Scanner(System.in);
		       do {
		    	   System.out.println("Introduce el dia");
		           dia = entrada.nextInt();
		           System.out.println("Introduce el mes");
		           mes = entrada.nextInt();
		           System.out.println("Introduce el anio");
		           anio = entrada.nextInt();
		           if (esFechaCorrecta(dia, mes, anio) == false &&
		esBisiesto(anio) == false) {
		                      System.out.println("FECHA INCORRECTA, INTRODUCE NUEVOS VALORES");
		           } else
		                      System.out.println("FECHA CORRECTA");
		 } while (esFechaCorrecta(dia, mes, anio) == false &&
		esBisiesto(anio) == false); 

		}
}


