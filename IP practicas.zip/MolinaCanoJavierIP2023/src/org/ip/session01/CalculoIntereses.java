package org.ip.session01;

public class CalculoIntereses {

	public static void main(String[] args) {
	 double DineroIngresado=2500;
	 double InteresAnual=0.0175;
	 double Interes6Meses=(DineroIngresado*InteresAnual)/2;
	 double Retencion=Interes6Meses*0.21;
	 double InteresesCobrados=Interes6Meses-Retencion;
	 
	 System.out.println("***Calculo de intereses***");
	 System.out.printf("Dinero ingresado: %.2f",DineroIngresado);
	 System.out.printf("€\n");
	 System.out.println("Interes anual: 1.75%");
	 System.out.printf("Interes a los 6 meses: %.2f",Interes6Meses);
	 System.out.printf("€");
	 System.out.printf("%nRetencion realizada: %.2f",Retencion);
	 System.out.printf("€");
	 System.out.printf("%nIntereses cobrados: %.2f",InteresesCobrados);
	 System.out.printf("€");
	 
	}
	
}