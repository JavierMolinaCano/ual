package org.ip.session01;

public class DivisionPorCero {

	public static void main(String[] args) {
		System.out.println();
		System.out.println("EJEMPLOS DE DIVISIONES POR CERO CON ENTEROS Y REALES");
		System.out.println();
		System.out.println("17.0 / 0.0 = " + (17.0 / 0.0)); // infinity
		System.out.println("17.0 % 0.0 = " + (17.0 % 0.0)); // not a number
		System.out.println("17 / 0 = " );
		System.out.println(17/0); //ERROR
	}
	
}