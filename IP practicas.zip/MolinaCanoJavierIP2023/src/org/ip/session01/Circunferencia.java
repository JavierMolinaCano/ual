package org.ip.session01;

public class Circunferencia {

	public static void main(String[] args) {
	 double radio=4.57;
	 double diametro=radio*2;
	 double perimetro=(2*Math.PI*radio);
	 double area=(Math.PI*Math.pow(radio,2));
	 
     System.out.printf("Radio = %.2f%n", radio);
	 System.out.printf("%nDiametro de la circunferencia = %2f",diametro);
	 System.out.printf("%nPerimetro de la circunferencia = %3f",perimetro);
	 System.out.printf("%nArea de la circunferencia = %.3f",area);
	}
	
}