package org.ip.session01;

public class Distancia {

	public static void main(String[] args) {
	 double origenx=0;
	 double origeny=0;
	 int puntox=2;
	 int puntoy=1;
	 double distancia=Math.sqrt(Math.pow((puntox-origenx),2)+Math.pow((puntoy-origeny),2));
	 
	 System.out.println("La distancia del punto (" + puntox + "," + puntoy + ") al punto (0,0) es " + distancia);
	 
	}
	
}