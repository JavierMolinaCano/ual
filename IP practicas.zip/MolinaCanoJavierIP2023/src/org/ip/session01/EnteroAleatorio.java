package org.ip.session01;

public class EnteroAleatorio {

	public static void main(String[] args) {
	 int N=15;
	 int M=-15;
	 int ValorEntero=(int)(Math.random()*((N-(M)+1))+M);
	 
	 System.out.println("Vamos a generar un entero aleatorio entre -15 y 15");
	 System.out.println("El entero generado aleatoriamente es: " + ValorEntero);
	 
	}
	
}