package org.ip.session06;

import java.util.Scanner;

public class TestCirculo {
	public static void main(String[] args) {
		Circulo1 circ1 = new Circulo1(1.0, 1.0, 1.0);
		Circulo1 circ2 = new Circulo1();
		Circulo1 circ3 = new Circulo1(0.0, 0.0);
		Circulo1 circ4 = new Circulo1(circ3);
		System.out.println("*** Programa que permite trabajar con circulos ***");
		System.out.println(); //Mostrar los circulos creados
		System.out.println("Circulo1 " + circ1.toString());
		System.out.println("Circulo2 " + circ2.toString());
		System.out.println("Circulo3 " + circ3.toString());
		System.out.println("Circulo4 " + circ4.toString()); //Comprobar si el circulo 1 es igual al 2
		if (circ1.equals(circ2))
		System.out.println("Circulos 1 y 2 son iguales");
		else
		System.out.println("Circulos 1 y 2 son distintos");
		//Comprobar si los circulos 2, 3 y 4 son iguales
		if (circ2.equals(circ3) && circ3.equals(circ4))
		System.out.println("Circulos 2, 3 y 4 son iguales");
		else
		System.out.println("Circulos 2, 3 y 4 son distintos");
		//Mostrar el numero de circulos creados
		System.out.println("El número de circulos creados es " + Circulo1.getNumCirculos());
		//Comparar el circulo 1 con el 2
		if(circ1.compareTo(circ2)==0)
		System.out.println("Circulo 1 es igual que el circulo 2 en area");
		else if (circ1.compareTo(circ2)==-1)
		System.out.println("Circulo 1 es mas pequeño que el circulo 2 en area");
		else
		System.out.println("Circulo 1 es mas grande que el circulo 2 en area");
		//Calcular area, diametro y longitud del circulo 1
		System.out.println("Circulo 1 => [<area>=" + circ1.calcularArea() + ", <diametro>="+ circ1.calcularDiametro() + "," 
				<longitud>=" + circ1.calcularLongitud() + "]"); "+"");
		//Introducir los valores de un nuevo circulo, mostrarlos y "obtener su area, longitud y diametro
		Circulo1 circ5 = new Circulo1();
		@SuppressWarnings("resource");
		}
}


