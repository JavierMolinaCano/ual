package org.ip.session06;

import java.util.Scanner;

public class Circulo1 implements Comparable<object> {
	public Circulo1(double d, double e) {
		// TODO Auto-generated constructor stub
	}
	public Circulo1(double d, double e, double f) {
		// TODO Auto-generated constructor stub
	}
	public Circulo1() {
		// TODO Auto-generated constructor stub
	}
	public Circulo1(Circulo1 circ3) {
		// TODO Auto-generated constructor stub
	}
	private double xCentro;
	private double yCentro;
	private double radio;
	private static int numCirculos = 0;
	public void Circulo(double xCentro, double yCentro, double radio) {
	super();
	this.xCentro = xCentro;
	this.yCentro = yCentro;
	this.radio = radio;
	numCirculos++;
	}
	public Circulo1(double radio) {
	super();
	this.radio = radio;
	numCirculos++;
	}
	public void Circulo(double xCentro, double yCentro) {
	super();
	this.xCentro = xCentro;
	this.yCentro = yCentro;
	numCirculos++;
	}
	public Circulo() {
	super();
	numCirculos++;
	}
	public Circulo(Circulo1 c) {
	this.xCentro = c.xCentro;
	this.yCentro = c.yCentro;
	this.radio = c.radio;
	numCirculos++;
	}
	public double getxCentro() {
	return xCentro;
	}
	public void setxCentro(double xCentro) {
	this.xCentro = xCentro;
	}
	public double getyCentro() {
	return yCentro;
	}
	public void setyCentro(double yCentro) {
	this.yCentro = yCentro;
	}
	public double getRadio() {
	return radio;
	}
	public void setRadio(double radio) {
	this.radio = radio;
	}
	public static int getNumCirculos() {
	return numCirculos;
	}
	@Override
	public String toString() {
	return "Circulo={(xCentro=" + xCentro + ", yCentro=" + yCentro
	+ "), radio=" + radio + "}";
	}
	@Override
	public boolean equals(Object obj) {
	if (this == obj)
	return true;
	if (obj == null)
	return false;
	if (getClass() != obj.getClass())
	return false;
	Circulo1 other = (Circulo1) obj;
	if (Double.doubleToLongBits(radio) !=
	Double.doubleToLongBits(other.radio))
	return false;
	if (Double.doubleToLongBits(xCentro) !=
	Double.doubleToLongBits(other.xCentro))
	return false;
	if (Double.doubleToLongBits(yCentro) !=
	Double.doubleToLongBits(other.yCentro))
	return false;
	return true;
	}
	public double calcularArea() {
	double area;
	area = Math.PI*Math.pow(this.radio, 2);
	return area;
	}
	public double calcularLongitud() {
	double longitud;
	longitud = 2*Math.PI*this.radio;
	return longitud;
	}
	public double calcularDiametro(){
	double diametro;
	diametro = 2*this.radio;
	return diametro;
	}
	@Override
	public int compareTo(Object o) {
		}
		
		public int compareTo(Circulo1 circ2) {
			// TODO Auto-generated method stub
			return 0;
		}
		@Override
		public int compareTo(object o) {
			// TODO Auto-generated method stub
			return 0;
		}
}


