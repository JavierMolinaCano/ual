package org.ip.session06;

import java.util.Scanner;

public class TestFraccion {
	public static void main(String[] args) {
		Fraccion frac1 = new Fraccion(1, 5);
		Fraccion frac2 = new Fraccion(4, 5);
		Fraccion frac3 = new Fraccion(-11, 22);
		Fraccion frac4 = new Fraccion(frac2);
		System.out.println("LAS FRACCIONES CREADAS SON");
		System.out.println();
		System.out.println("PRIMERA FRACCION => " + frac1.toString());
		System.out.println("SEGUNDA FRACCION => " + frac2.toString());
		System.out.println("TERCERA FRACCION => " + frac3.toString());
		System.out.println("CUARTA FRACCION => " + frac4.toString());
		System.out.println();
		//Numero de fracciones creadas
		System.out.println("El numero de fracciones creadas es " +
		Fraccion.getNumFracciones());
		//Comprobar si la primera fracción es igual a la segunda
		if (frac1.equals(frac2))
		System.out.println("La primera fraccion ES IGUAL a la segunda");
		else
		System.out.println("La primera fraccion NO ES IGUAL a la segunda");
		//Comprobar si la segunda fracción es igual a la cuarta
		if (frac2.equals(frac4))
		System.out.println("La segunda fraccion ES IGUAL a la cuarta");
		else
		System.out.println("La segunda fraccion NO ES IGUAL a la cuarta");
		//Mostrar el numerador de la tercera fracción
		System.out.println("El numerador de la tercera fraccion es => " +
		frac3.getNumerador());
		//Mostrar el denominador de la primera fracción
		System.out.println("El denominador de la primera fraccion es => " +
		frac1.getDenominador());
		//Mostrar la suma de la primera y segunda fracción
		System.out.println("La suma, utilizando el metodo de clase de " +
		frac1 + " + " + frac2 + " es " + frac1.sumar(frac2));
		System.out.println("La suma, utilizando el metodo de objeto de " +
		frac1 + " + " + frac2 + " es " + Fraccion.sumar(frac1,frac2) +
		" simplificada " +
		Fraccion.sumar(frac1,frac2).simplificar());
		//Mostrar la resta de la primera y segunda fracción
		System.out.println("La resta de " + frac1 + " - " + frac2 + " es "
		+ frac1.restar(frac2) + " simplificada " +
		(frac1.restar(frac2)).simplificar());
		//Mostrar el producto de la primera y segunda fracción.
		System.out.println("El producto " + frac1 + " x " + frac2 + " es "
		+ frac1.multiplicar(frac2));
		//Mostrar la división de la primera y tercera fracción.
		System.out.println("La division de " + frac1 + " / " + frac3 + " es " + frac1.dividir(frac3));
		//Mostrar la tercera fracción simplificada.
		}
}


