package org.ip.session06;

import java.util.Scanner;

public class Fraccion {
		private int numerador;
	private int denominador;
	private static int numFracciones;
	public Fraccion() {
	super();
	this.numerador=0;
	this.denominador=1;
	numFracciones++;
	}
	public Fraccion(int numerador, int denominador) {
	super();
	this.numerador = numerador;
	this.denominador = denominador;
	numFracciones++;
	}
	public Fraccion(Fraccion fraccion) {
	this.numerador=fraccion.numerador;
	this.denominador=fraccion.denominador;
	numFracciones++;
	}
	@Override
	public boolean equals(Object obj) {
	if (this == obj)
	return true;
	if (obj == null)
	return false;
	if (getClass() != obj.getClass())
	return false;
	Fraccion other = (Fraccion) obj;
	if (denominador != other.denominador)
	return false;
	if (numerador != other.numerador)
	return false;
	return true;
	}
	public int getNumerador() {
	return numerador;
	}
	public int getDenominador() {
	return denominador;
	}
	public static int getNumFracciones() {
	return numFracciones;
	}
	@Override
	public String toString() {
	if (denominador == 1)
	return numerador + "";
	else
	return numerador + "/" + denominador;
	}
	public Fraccion sumar (Fraccion f) {
	Fraccion f1 = new Fraccion();
	f1.denominador = this.denominador * f.getDenominador();
	f1.numerador = this.numerador * f.getDenominador() +
	this.denominador * f.getNumerador();
	return f1;
	}
	public static Fraccion sumar (Fraccion a, Fraccion b) {
	Fraccion f1 = new Fraccion();
	f1.denominador = a.denominador * b.denominador;
	f1.numerador = a.numerador * b.denominador +
	a.denominador*b.numerador;
	return f1;
	}
	public Fraccion restar (Fraccion f) {
	Fraccion f1 = new Fraccion();
	f1.denominador = this.denominador * f.getDenominador();
	f1.numerador = this.numerador * f.getDenominador() -
	this.denominador * f.getNumerador();
	return f1;
	}
	public Fraccion multiplicar (Fraccion f) {
	Fraccion f1 = new Fraccion();
	f1.denominador = this.denominador * f.getDenominador();
	f1.numerador = this.numerador * f.getNumerador();
	return f1;
	}
	public Fraccion dividir (Fraccion f) {
	Fraccion f1 = new Fraccion();
	f1.denominador = this.denominador * f.getNumerador();
	f1.numerador = this.numerador * f.getDenominador();
	return f1;
	}
	private int mcd (int u, int v) {
	int resto;
	u=Math.abs(u);
	v=Math.abs(v);
	if(v==0)
	return u;
	do{
	resto=u%v;
	u=v;
	v = resto;
	}while(resto!=0);
	return u;
	}
	public String simplificar() {
		// TODO Auto-generated method stub
		return null;
	}	
}



