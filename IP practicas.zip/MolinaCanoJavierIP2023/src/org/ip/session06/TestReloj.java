package org.ip.session06;

import java.util.Scanner;

public class TestReloj {
	public static void main(String[] args) {
		//Primer reloj
		Reloj r1 = new Reloj();
		//Se fija a 23:59:59
		r1.setHora(23);
		r1.setMinuto(59);
		r1.setSegundo(59);
		//Se muestra
		r1.mostrarReloj();
		System.out.println();
		//Se incrementa 1 segundo y se vuelve a mostrar
		r1.incrementarSegundo();
		r1.mostrarReloj();
		System.out.println("\n");
		//Segundo reloj
		//Se crea el reloj con los parámetros 24:60:60
		Reloj r2 = new Reloj(24,60,60);
		//Se muestra
		r2.mostrarReloj();
		System.out.println();
		//Se incrementa 1 segundo, minuto y hora y se vuelve a mostrar
		r2.incrementaHora();
		r2.incrementarMinuto();
		r2.incrementarSegundo();
		r2.mostrarReloj();
		System.out.println("\n");
		//Tercer reloj
		//Creamos el reloj que sera igual que el primero y lo
		mostramos
		Reloj r3 = new Reloj(r1);
		r3.mostrarReloj();
		System.out.println();
		//Incrementamos 86400 segundos y mostramos
		for (int i=0;i<86400;i++) {
		r3.incrementarSegundo();
		}
		r3.mostrarReloj();
		System.out.println("\n");
		//Cuarto reloj
		//Creamos un reloj igual al primero y lo mostramos
		Reloj r4 = new Reloj(r1);
		r4.mostrarReloj();
		System.out.println();
		//Incrementamos en 1440 los minutos y mostramos
		for (int i=0;i<1440;i++) {
		r4.incrementarMinuto();
		}
		r4.mostrarReloj();
		System.out.println("\n");
		//Reloj 5
		//Creamos un reloj igual al primero y lo mostramos
		Reloj r5 = new Reloj(r1);
		}
}


