package org.ip.session03;

public class TrianguloRectanguloNumeros{

	public static void main(String[] args) {
		int lado = 10;
		System.out.println("Triangulo rectangulo de numeros para un valor de lado = " + lado);
		System.out.println();
		for (int i = 0; i < lado; i++) {
			for (int j = lado - 1; j > i; j--) {
				System.out.print(" ");
		}
		for (int k = 0; k <= i; k++) {
			System.out.print(i - k + " ");
		}
		System.out.println();
	}
}
}