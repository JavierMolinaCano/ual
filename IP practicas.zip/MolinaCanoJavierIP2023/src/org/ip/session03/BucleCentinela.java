package org.ip.session03;

import java.util.Scanner;

public class BucleCentinela {
	public static void main(String[] args) {
		System.out.println("Introduce valores enteros, el programa termina si la entrada es 0");
				int np=0;
				int nn=0;
				int nv=-1;
				int sp=0;
				int sn=0;
				int numeros=1;
				
				Scanner entrada=new Scanner(System.in);
				
				while(numeros!=0) {
					numeros=entrada.nextInt();
					if(0<numeros) {
						np=np+1;
						sp=sp+numeros;
				    }
					else if(numeros<0) {
						nn=nn+1;
						sn=sn+numeros;
					}
					nv++;
				}
				double media=(sp+sn)/nv;
				
				System.out.println("El numero de positivos es " + np);
				System.out.println("El numero de negativos es " + nn);
				System.out.println("El numero total de valores leidos es " + nv);
				System.out.println("La suma de positivos es " + sp);
				System.out.println("La suma de negativos es " + sn);
				System.out.println("La media de los valores es " + media);
				}
}


