package org.ip.session03;

import java.util.Scanner;

public class Primo{

	public static void main(String[] args) {
		int dato;
		int divisor = 2;
		boolean primo = true;
		@SuppressWarnings("resource")
		Scanner entrada = new Scanner(System.in);
		do {
			System.out.print("Introduce un numero (>1) para saber si es primo: ");
			dato = entrada.nextInt();
		} while (dato <= 1);
		
		if (dato % divisor == 0)
		primo = false;
		
		while (divisor <= Math.sqrt(dato)) {
			if (dato % divisor == 0) {
				primo = false;
		}
		divisor++;
	}
	if (dato == 2)
		primo = true;
	if (primo)
		System.out.println("ES PRIMO");
	else
		System.out.println("NO ES PRIMO");
	}	
}