package org.ip.session03;

import java.util.Scanner;

public class TablaMultiplicar{

	public static void main(String[] args) {
		int numero;
		@SuppressWarnings("resource")
		Scanner entrada = new Scanner(System.in);
		do {
			System.out.print("Introduzca un numero (de 1 a 10): ");
			numero = entrada.nextInt();
			System.out.println();
		} while (numero > 10 || numero < 1);
		System.out.println("Tabla del " + numero);
		for (int i = 1; i <= 10; i++) {
			System.out.println(numero + " x " + i + " = " + numero *i);
			}
	}	
}