package org.ip.session03;

import java.util.Scanner;

public class Euclides{

	public static void main(String[] args) {
		int x, y, q, valor1, valor2;
		 @SuppressWarnings("resource")
		 Scanner entrada = new Scanner(System.in);
		 System.out.println("Introduce el primer valor entero positivo");
		 valor1 = entrada.nextInt();
		 while (valor1 < 0) {
			 System.out.println("Introduce el primer valor entero positivo");
			 valor1 = entrada.nextInt();
		 }
		 System.out.println("Introduce el segundo valor entero positivo");
		 valor2 = entrada.nextInt();
		 while (valor2 < 0) {
		System.out.println("Introduce el segundo valor entero positivo");
		valor2 = entrada.nextInt();
		 }
		 x = valor1;
		 y = valor2;
		 while (x % y != 0) {
		 q = x;
		 x = y;
		 y = q % y;
		 }
		 System.out.println("El MCD de " + valor1 + " y " + valor2 + " es " + y);
	}	
}