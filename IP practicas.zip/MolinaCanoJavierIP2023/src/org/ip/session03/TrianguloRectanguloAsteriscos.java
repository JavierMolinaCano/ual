package org.ip.session03;

public class TrianguloRectanguloAsteriscos{

	public static void main(String[] args) {
		int lado = 7;
		System.out.println("Triangulo rectangulo de numeros para un valor de lado " + lado);
		System.out.println();
		for (int i = 0; i < lado; i++) {
		for (int k = lado - 1; k >= i; k--) {
		System.out.print("* ");
		}
		System.out.println();
	}	
}
}