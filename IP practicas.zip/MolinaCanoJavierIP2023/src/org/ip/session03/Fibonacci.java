package org.ip.session03;

import java.util.Scanner;

public class Fibonacci{

	public static void main(String[] args) {
		int n, i;
		@SuppressWarnings("resource")
		Scanner entrada = new Scanner(System.in);
		System.out.println("Hasta que termino de la serie de Fibonacci quieres mostrar?");
		n = entrada.nextInt();
		if (n == 0) {
		System.out.println("0");
		} 
		else if (n == 1) {
		System.out.println("0 1");
		} 
		else {
			int f0 = 0;
			int f1 = 1;
			i = 2;
			int fi = f0 + f1;
			System.out.print("0 1 1 ");
			while (i < n) {
				f0 = f1;
				f1 = fi;
				fi = f0 + f1;
				i++;
				System.out.print(fi + " ");
			}
		}
	}
}	
