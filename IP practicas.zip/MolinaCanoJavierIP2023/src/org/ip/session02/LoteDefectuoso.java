package org.ip.session02;

public class LoteDefectuoso {

	public static void main(String[] args) {
	 int lote = 25000;
	 if(5300<=lote && lote <=5399);
	 System.out.println("El codigo" + lote + "corresponde a un lote DEFECTUOSO");
	 { if(33001<=lote && lote<=39999) 
		System.out.println("El codigo" + lote + "corresponde a un lote DEFECTUOSO");
	}
	 if(178000<=lote && lote<=191499) {
		System.out.println("El codigo" + lote + "corresponde a un lote DEFECTUOSO");
	}
	else {
		System.out.println("El codigo" + lote + "corresponde a un lote NO DEFECTUOSO");
	    }
    }
	
}
	