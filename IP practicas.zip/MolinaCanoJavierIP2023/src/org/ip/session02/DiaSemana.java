package org.ip.session02;

public class DiaSemana{

	public static void main(String[] args) {
		int d=3;
		int m=3;
		int y=2006;
		double y0 = y - (14 - m) / 12;
		double x = y0 + y0 / 4 - y0 /100 + y0 / 400;
		double m0 = m + 12 * ((14 - m) / 12) - 2;
		int d0 =(int) (d + x + (31 * m0) / 12) % 7;
		
		if(d0==1) {
			System.out.println("El dia de la semana correspondiente al " + d + "/" + m + "/" + y + " es :");
			System.out.println();
			System.out.println("DOMINGO");
		}
		else if(d0==2) {
			System.out.println("El dia de la semana correspondiente al " + d + "/" + m + "/" + y + " es :");
			System.out.println();
			System.out.println("LUNES");
		}
		else if(d0==3) {
			System.out.println("El dia de la semana correspondiente al " + d + "/" + m + "/" + y + " es :");
			System.out.println();
			System.out.println("MARTES");
		}
		else if(d0==4) {
			System.out.println("El dia de la semana correspondiente al " + d + "/" + m + "/" + y + " es :");
			System.out.println();
			System.out.println("MIERCOLES");
		}
		else if(d0==5) {
			System.out.println("El dia de la semana correspondiente al " + d + "/" + m + "/" + y + " es :");
			System.out.println();
			System.out.println("JUEVES");
	    }
		else if(d0==6) {
			System.out.println("El dia de la semana correspondiente al " + d + "/" + m + "/" + y + " es :");
			System.out.println();
			System.out.println("VIERNES");
		}
		else if(d0==7) {
			System.out.println("El dia de la semana correspondiente al " + d + "/" + m + "/" + y + " es :");
			System.out.println();
			System.out.println("SABADO");
		}
	}
	
}