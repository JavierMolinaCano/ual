package org.ip.session02;

public class TarifaTaxi{

	public static void main(String[] args) {
	 int kilometros=101;
	 
	 System.out.println("CALCULO TARIFA TAXI");
	 System.out.println();
	 System.out.println("Kilometros recorridos =>" + kilometros);
	 
	 if(kilometros<=30) {
		 System.out.println("El importe total a pagar es 18 euros");
	 }
	 
	 else if(30<kilometros && kilometros<=100) {
		 System.out.printf("El importe total a pagar es %.2f", (18+0.85*(kilometros-30)));
		 System.out.printf("euros");
	 }
	 
	 else {
		 System.out.printf("El importe total a pagar es %.2f",(18+0.85*70+0.65*(kilometros-100)));
		 System.out.printf("euros");
	 }
	}
	
}