package org.ip.session02;

public class FechaCorrecta{

	public static void main(String[] args) {
	 int dia=29;
	 int mes=2;
	 int anio=2020;
	 boolean fechacorrecta = false;
	 
	 if(1500<=anio && anio<=3000) {
		 if(mes==1 || mes==3 || mes==5 || mes==7 || mes==8 || mes==10 || mes==12) {
			 if(0<=dia && dia<=31) {
				 fechacorrecta=true;
			 }
			 else {
				 fechacorrecta=false; 
			 }
		 }
		 else if(mes==4 || mes==6 || mes==9 || mes==11) {
			 if(0<dia && dia<=30) {
				 fechacorrecta=true;
			 }
		 }
		 else if(mes==2) {
			 if(anio%4==0 && anio%100!=0) {
				 fechacorrecta=true;
			 }
			 else {
				 fechacorrecta=false;;
			 }
		 }
	 }
	 else {
		 fechacorrecta=false;
	 }
	 if(fechacorrecta==true) {
		 System.out.println("Fecha correcta: " + dia + "/" + mes + "/" + anio);
	 }
	 else {
		 System.out.println("Fecha incorrecta - " + dia + "/" + mes + "/" + anio);
	 }
	}
	
}