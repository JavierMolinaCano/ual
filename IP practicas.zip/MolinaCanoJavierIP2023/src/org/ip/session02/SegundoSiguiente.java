package org.ip.session02;

public class SegundoSiguiente{

	public static void main(String[] args) {
		int hora = 1;
		int minuto = 1;
		int segundo = 1;
		
		System.out.printf("Instante de tiempo actual %02d:%02d:%02d %n",hora,minuto,segundo);
		
		segundo=segundo+1;
		
		if(0<=segundo && segundo<=59) {
			System.out.printf("Instante de tiempo un segundo despues : %02d:%02d:%02d",hora,minuto,segundo);	
		}
		else if(segundo==60) {
			segundo=00;
			minuto=minuto+1;
			
			if(minuto==60) {
				minuto=00;
				hora=hora+1;
				
				if (hora==24) {
					hora=00;
					minuto=00;
					segundo=00;
				}
			}
			System.out.printf("Instante de tiempo un segundo despues : %02d:%02d:%02d",hora,minuto,segundo);
		}
	}
}