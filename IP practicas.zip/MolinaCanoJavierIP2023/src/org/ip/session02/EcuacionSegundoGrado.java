package org.ip.session02;

public class EcuacionSegundoGrado {

	public static void main(String[] args) {
	 System.out.println("SOLUCION DE UNA ECUACION DE SEGUNDO GRADO");
	 System.out.println();
	 
	 int a=1;
	 int b=2;
	 int c=1;
	 
	 double Raiz= Math.sqrt (Math.pow(b, 2)-4*a*c);
	 double DividendoPositivo= -b+Raiz;
	 double DividendoNegativo= -b-Raiz;
	 double Divisor= 2*a;
	 double solucion1= DividendoPositivo/Divisor;
	 double solucion2= DividendoNegativo/Divisor;
	 
	 System.out.println("Valores de los coeficientes");
	 System.out.println();
	 System.out.println("a = " + a + ", b = " + b + ", c = " + c);
	 System.out.println();
	 
	 if(a==0) {
		 System.out.println("No es una ecuacion de segundo grado");
	 }
	 else if (Math.pow(b, 2)<4*a*c) {
		 System.out.println("No tiene solucion real");
	 }
	 else if (Raiz==0) {
		 System.out.println("Solo tiene una solucion real x = " + solucion1);
	 }
	 else if (Raiz>0) {
		 System.out.println("Dos raices de valores");
		 System.out.println("x1 = " + solucion1);
		 System.out.println("x2 = " + solucion2);
	 }
	}
	
}