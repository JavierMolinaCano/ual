package org.ip.session05;

import java.util.Scanner;

public class EntradaSalidaArrays {
	public static double[] leerRealesArray1D() {
		Scanner entrada = new Scanner(System.in);
		System.out.printf("Introduzca el tamaño del array real: ");
		int tamano = entrada.nextInt();
		double [] valores = new double[tamano];
		
		for(int i=0; i< valores.length;i++) {
			System.out.printf("Introduzca el valor [" + i + "] ==> ");
			valores[i]= entrada.nextInt();
		}
		return valores;
	}
	public static int [] leerEnterosArray1D() {
		Scanner entrada	= new Scanner(System.in);
		System.out.printf("Introduzca el tamaño del array entero: ");
		int tamano = entrada.nextInt();
		int [] valores = new int[tamano];
		
		for(int	i=0;i< valores.length;i++)	{
			System.out.printf("Introduzca el valor [" + i + "] ==> ");
		    valores[i]= entrada.nextInt();
		    }
		    return valores;
	}
	public static int [] inicializarEnterosArray1D() {
		int N = 50;
		Scanner entrada	= new Scanner(System.in);
		System.out.printf("Introduzca el tamaño del array entero: ");
		int tamano = entrada.nextInt();
		int [] valores = new int[tamano];
		
		for(int i =	0; i< valores.length; i++)	{
		     valores[i]	= (int)(Math.random()*N);
		}
		     return valores;
	}
	public static double [] inicializarRealesArray1D()	{
		double N= 50;
		Scanner entrada	= new Scanner(System.in);
		System.out.printf("Introduzca el tamaño del array real: ");
		int tamano= entrada.nextInt();
		double [] valores = new double[tamano];
		
		for(int	i =	0;	i< valores.length; i++) {
			valores[i]=(Math.random()*N);
		}
		return valores;
	}
	public static void mostrarArray1D(double [] array)	{
		for(int	i = 0; i<array.length;i++) {
		System.out.printf("\t%.3f", array[i]);
		}
		System.out.println();
		}
	public static void mostrarArray1D
		(int [] array) {
		for(int i =	0; i< array.length;	i++) {
			System.out.print(array[i]+ " ");
		}
		System.out.println();
	}
	public static int [][] leerEnterosMatriz2D(){
		Scanner entrada = new Scanner(System.in);
		System.out.printf("Introduzca el tamaño del array bidimensional entero: ");
		int tamano = entrada.nextInt();
		int [][] valores2D = new int[tamano][tamano];
		for(int i = 0; i< valores2D.length; i++) {
			for(int	j = 0; j< valores2D[i].length; j++)	{
				System.out.printf("Introduzca el valor [" +	i + "][" + j + "] ==> ");
				valores2D[i][j] = entrada.nextInt();
				}
		}
		return valores2D;
	}
	public static int [][] inicializarEnterosMatriz2D(){
		int	N = 50;
		Scanner entrada	= new Scanner(System.in);
		System.out.printf("Introduzca el tamaño del array bidimensional: ");
		int tamano = entrada.nextInt();
		int [][] valores2D = new int[tamano][tamano];
		for(int i=0;i< valores2D.length;i++) {
			for(int j=0;j< valores2D[i].length;	j++){
				valores2D[i][j]=(int)(Math.random()	*N);
				}
		}
		return valores2D;
		}
	public static void mostrarMatriz2D(int [][] matriz)	{
				for(int	i=0;i< matriz.length;i++) {
					for(int	j=0;j< matriz[i].length;j++) {
						System.out.printf(matriz[i][j] + "\t");
				}
				System.out.println();
			}
		}
	public static void mostrarMatriz2D(double [][] matriz) {
		for(int	i=0; i< matriz.length;i++) {
			for(int	j=0;j< matriz[i].length;j++) {
				System.out.printf(matriz[i][j]+	"\t");
				}
			System.out.println();
			}
		}
	public static void main(String[] args) {// TODO Auto-generated method stub
				int [] arrayEnteros;
				double [] arrayReales;
				int [] arrayEnterosAleatorios;
				double [] arrayRealesAleatorios;
				int [][] matriz2D;
				arrayReales	= leerRealesArray1D();
				arrayEnteros = leerEnterosArray1D();
				arrayEnterosAleatorios = inicializarEnterosArray1D();
				arrayRealesAleatorios = inicializarRealesArray1D();
				mostrarArray1D(arrayEnteros);
				mostrarArray1D(arrayReales);
				mostrarArray1D(arrayEnterosAleatorios);
				mostrarArray1D(arrayRealesAleatorios);
				matriz2D = inicializarEnterosMatriz2D();
				
				mostrarMatriz2D(matriz2D);
				matriz2D = leerEnterosMatriz2D();
				mostrarMatriz2D(matriz2D);
				}
}


