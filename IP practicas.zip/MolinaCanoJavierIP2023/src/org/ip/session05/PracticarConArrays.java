package org.ip.session05;

public class PracticarConArrays {
	public static int [] invertir(int [] array) {
		int []arrayInvertido=new int [array.length];
		for(int i=0;i<array.length;i++) {
		arrayInvertido[(array.length-1)-i]=array[i];
		}
		return arrayInvertido;
		}
		public static void mostrarArray(int [] array) {
		System.out.print("Array de enteros: ");
		System.out.print("[");
		for (int i = 0; i < array.length; i++) {
		System.out.print(array[i]);
		if(i<array.length-1) {
		System.out.print( ", ");
		}
		}System.out.println("]");
		}
		public static void desplazar(int [] array) {
		int auxiliar=array[0];
		for(int i=0;i<array.length-1;i++) {
		array[i]=array[i+1];
		}
		array[array.length-1]=auxiliar;
		}
		public static int indiceMaximoValor(int [] array) {
		int max=0;
		for(int i=1;i<array.length;i++) {
		if(array[i]>array[max]) {
		max=i;
		}
		}
		return max;
		}
		public static int indiceMinimoValor(int [] array) {
		int min=0;
		for(int i=1;i<array.length;i++) {
		if(array[min]>array[i]) {
		min=i;
		}
		}
		return min;
		}
		public static void eliminarDuplicados(int [] array) {
		int [] arrayAuxiliar = new int[array.length];
		}
}


