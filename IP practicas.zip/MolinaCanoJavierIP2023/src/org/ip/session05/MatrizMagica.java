package org.ip.session05;

import java.util.Scanner;

public class MatrizMagica {
	public static boolean esMatrizMagica(int [][] matriz) {
		int sumaPatron=0;
		for(int c=0;c<matriz[0].length;c++){
	    sumaPatron+=matriz[0][c];
		}
		for(int c=0;c<matriz.length;c++) {
		int sumaColumna=0;
		for(int f=0;f<matriz.length;f++) {
		sumaColumna+=matriz[f][c];
		}
		if(sumaColumna!=sumaPatron) {
		return false;
		}
		}
		for(int f=0;f<matriz.length;f++) {
		int sumaFila=0;
		for(int c=0;c<matriz.length;c++) {
		sumaFila+=matriz[f][c];
		}
		if(sumaFila!=sumaPatron) {
		return false;
		}
		}
		return true;
		}
		public static void main(String[] args) {
		Scanner entrada= new Scanner(System.in);
		int [][]matriz= new int [4][4];
		for(int i=0;i<matriz.length;i++){
		for(int j=0;j<matriz[0].length;j++){
		System.out.print("M["+i+"]"+"["+j+"]: ");
		matriz[i][j] = entrada.nextInt();
		}
		}
		if(esMatrizMagica(matriz)) {
		System.out.println("La matriz es magica");
		}
		else {
		System.out.println("La matriz no es magica");
		}
}
}


