package org.ip.session05;

import java.util.Scanner;

public class MatricesBinarias {
	public static void mostrarMatriz(int [][] matriz) {
		System.out.println("Matriz: ");
		System.out.print("[");
		for (int i = 0; i < matriz.length; i++) {
		for(int j=0;j<matriz[i].length;j++) {
		System.out.print(matriz[i][j]);
		if(j<matriz[0].length-1) {
		System.out.print("\t");
		}
		}if(i!=matriz.length-1) {
		System.out.println();
		}
		}
		System.out.println("]");
		}
		public static boolean esBinaria(int [][] matriz) {
		for(int i=0;i<matriz.length;i++) {
		for(int j=0;j<matriz.length;j++) {
		if(matriz[i][j]!=0 && matriz[i][j]!=1) {
		return false;
		}
		}
		}
		return true;
		}
		public static int [][] transformaBinaria(int [][] matriz){
		int [][]matrizAux=new int [matriz.length][matriz.length];
		for(int i=0;i<matriz.length;i++) {
		for(int j=0;j<matriz.length;j++) {
		if(matriz[i][j]%2==0) {
		matrizAux[i][j]=0;
		}
		else if(matriz[i][j]%2==1) {
		matrizAux[i][j]=1;
		}
		}
		}
		return matrizAux;
		}
		public static int numeroDeUnos(int [][] matriz) {
		int num1s=0;
		for(int i=0;i<matriz.length;i++) {
		for(int j=0;j<matriz.length;j++) {
		if(matriz[i][j]==1) {
		num1s++;
		}
		}
		}
		return num1s;
		}
		public static boolean tieneNumeroParCeros(int [][] matriz) {
		int num0s=0;
		for(int i=0;i<matriz.length;i++) {
		for(int j=0;j<matriz.length;j++) {
		if(matriz[i][j]==0) {
		num0s++;
		}
		}
		if(num0s%2==0&&num0s!=0) {
		return true;
		}
		}
		return false;
		}
		public static int [] sumaFilas(int [][] matriz) {
		int []arraySumaFilas= new int [matriz.length];
		for(int i=0;i<matriz.length;i++) {
		for(int j=0;j<matriz.length;j++) {
		arraySumaFilas[i]+=matriz[i][j];
		}
		}return arraySumaFilas;
		}
		public static void mostrarArray(int [] array) {
		System.out.print(" Array: ");
		System.out.print("[");
		for (int i = 0; i < array.length; i++) {
		System.out.print(array[i]);
		if(i<array.length-1) {
		System.out.print("\t");
		}
		}System.out.println("]");
		}
		public static int [] sumaColumnas(int [][] matriz) {
		int []arraySumaColumnas=new int [matriz.length];
		for(int c=0;c<matriz[0].length;c++) {
		for(int f=0;f<matriz.length;f++){
		arraySumaColumnas[c]+=matriz[f][c];
		}
		}
		return arraySumaColumnas;
		}
		public static int [] extraerFila(int [][] matriz, int numFila) {
		int []arrayFilas=new int [matriz.length];
		for(int j=0;j<matriz.length;j++) {
		arrayFilas[j]=matriz[numFila][j];
		}
		return arrayFilas;
		}
		public static void extraerColumna(int [][] matriz, int numColumna) {
		}
}


