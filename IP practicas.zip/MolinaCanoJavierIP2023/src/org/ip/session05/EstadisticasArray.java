package org.ip.session05;

public class EstadisticasArray {
	public static double max(double[] array) {
		double max=array[1];
		for(int i=0;i<array.length;i++) {
		if(array[i]>max) {
		max=array[i];
		}
		}
		return max;
		}
		public static int max(int [] array) {
		int max=0;
		for(int i=0;i<array.length;i++) {
		if(array[i]>max) {
		max=array[i];
		}
		}
		return max ;
		}
		public static double min(double[] array) {
		double min=array[0];
		for(int i=0;i<array.length;i++) {
		if(min>array[i]) {
		min=array[i];
		}
		}
		return min;
		}
		public static int min(int [] array) {
		int min=array[0];
		for(int i=0;i<array.length;i++) {
		if(min>array[i]) {
		min=array[i];
		}
		}
		return min;
		}
		public static double media(double[] array) {
		double media=0;
		for(int i=0;i<array.length;i++) {
		media += array[i]/array.length;
		}
		return media;
		}
		public static double media(int [] array) {
		double media=0;
		for(int i=0;i<array.length;i++) {
		media += array[i];
		}
		return media/array.length;
		}
		public static double varianza(double[] array) {
		double varianza=0;
		for(int i=0;i<array.length;i++) {
		varianza+=(Math.pow(array[i]-media(array), 2))/(array.length-
		1);
		}
		return varianza;
		}
		public static double varianza(int [] array) {
		double varianza=0;
		for(int i=0;i<array.length;i++) {
		varianza+=(Math.pow(array[i]-media(array), 2))/(array.length-
		1);
		}
		return varianza;
		}
		public static double desviacionTipica(double [] array) {
		double stdDev=0;
		stdDev=Math.sqrt(varianza(array));
		return stdDev;
		}
		public static double desviacionTipica(int [] array) {
		double stdDev=0;
		stdDev=Math.sqrt(varianza(array));
		return stdDev;
		}
		public static void mostrarArray(double [] array) {
		System.out.print("Array de reales: ");
		System.out.print("[");
		for (int i = 0; i < array.length; i++) {
		System.out.print(array[i]);
		if(i<array.length-1) {
		System.out.print( ", ");
		}
		}System.out.println("]");
		}
		public static void mostrarArray(int [] array) {
		System.out.print("Array de enteros: ");
		System.out.print("[");
		for (int i = 0; i < array.length; i++) {
		System.out.print(array[i]);
		if(i<array.length-1) {
		System.out.print( ", ");
		}
		}System.out.println("]");
		}
		public static void main(String[] args) {
		double [] array = {5.0,25.5,15.75,10.25,12.5};
		}
}


